y = ('a'..'z')
puts y.to_a.shuffle.to_s
puts (50...100).include?(100)
puts (1..3).include?(3)
puts (1..100).last
puts (1..100).last(10)
puts (1..100).min
puts (1..100).max
